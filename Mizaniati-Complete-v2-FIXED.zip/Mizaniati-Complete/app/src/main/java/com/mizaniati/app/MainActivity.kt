package com.mizaniati.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val CASH = "نقدي"
private const val BANK = "بنكي"
private val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
private fun today() = dateFmt.format(Date())
private fun fmt(n: Double) = String.format(Locale.US, "%,.2f", n)

data class Tx(
    val id: Long, val kind: String, val title: String, val amount: Double,
    val account: String, val category: String, val date: String, val note: String
)
data class Debt(
    val id: Long, val kind: String, val person: String, val phone: String,
    val total: Double, val paid: Double, val due: String, val note: String
) { val remaining get() = (total - paid).coerceAtLeast(0.0) }
data class Commitment(
    val id: Long, val title: String, val amount: Double, val account: String,
    val category: String, val dueDay: String, val note: String
)

class FinanceDb(ctx: Context) : SQLiteOpenHelper(ctx, "mizaniati.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE tx(id INTEGER PRIMARY KEY, kind TEXT, title TEXT, amount REAL, account TEXT, category TEXT, date TEXT, note TEXT)""")
        db.execSQL("""CREATE TABLE debts(id INTEGER PRIMARY KEY, kind TEXT, person TEXT, phone TEXT, total REAL, paid REAL, due TEXT, note TEXT)""")
        db.execSQL("""CREATE TABLE commitments(id INTEGER PRIMARY KEY, title TEXT, amount REAL, account TEXT, category TEXT, dueDay TEXT, note TEXT)""")
        db.execSQL("CREATE INDEX tx_date_idx ON tx(date)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    private fun values(vararg pairs: Pair<String, Any?>) = ContentValues().apply {
        pairs.forEach { (k,v) -> when(v) {
            null -> putNull(k); is String -> put(k,v); is Long -> put(k,v)
            is Int -> put(k,v); is Double -> put(k,v); is Float -> put(k,v)
            else -> put(k,v.toString())
        } }
    }
    fun addTx(t: Tx) { writableDatabase.insert("tx", null, values("kind" to t.kind,"title" to t.title,"amount" to t.amount,"account" to t.account,"category" to t.category,"date" to t.date,"note" to t.note)) }
    fun txs(): List<Tx> = readableDatabase.rawQuery("SELECT * FROM tx ORDER BY date DESC, id DESC", null).use { c ->
        buildList { while(c.moveToNext()) add(Tx(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getString(4),c.getString(5),c.getString(6),c.getString(7))) }
    }
    fun deleteTx(id: Long) { writableDatabase.delete("tx","id=?", arrayOf(id.toString())) }
    fun addDebt(d: Debt) { writableDatabase.insert("debts",null,values("kind" to d.kind,"person" to d.person,"phone" to d.phone,"total" to d.total,"paid" to d.paid,"due" to d.due,"note" to d.note)) }
    fun debts(): List<Debt> = readableDatabase.rawQuery("SELECT * FROM debts ORDER BY id DESC",null).use { c ->
        buildList { while(c.moveToNext()) add(Debt(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getDouble(4),c.getDouble(5),c.getString(6),c.getString(7))) }
    }
    fun updateDebtPaid(id: Long, paid: Double) { writableDatabase.update("debts",values("paid" to paid),"id=?",arrayOf(id.toString())) }
    fun deleteDebt(id: Long) { writableDatabase.delete("debts","id=?",arrayOf(id.toString())) }
    fun addCommitment(x: Commitment) { writableDatabase.insert("commitments",null,values("title" to x.title,"amount" to x.amount,"account" to x.account,"category" to x.category,"dueDay" to x.dueDay,"note" to x.note)) }
    fun commitments(): List<Commitment> = readableDatabase.rawQuery("SELECT * FROM commitments ORDER BY id DESC",null).use { c ->
        buildList { while(c.moveToNext()) add(Commitment(c.getLong(0),c.getString(1),c.getDouble(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6))) }
    }
    fun deleteCommitment(id: Long) { writableDatabase.delete("commitments","id=?",arrayOf(id.toString())) }

    fun exportJson(): String {
        val root = JSONObject()
        root.put("format","mizaniati-backup-v1")
        root.put("transactions", JSONArray().apply { txs().forEach { put(JSONObject().apply {
            put("kind",it.kind);put("title",it.title);put("amount",it.amount);put("account",it.account);put("category",it.category);put("date",it.date);put("note",it.note)
        }) } })
        root.put("debts", JSONArray().apply { debts().forEach { put(JSONObject().apply {
            put("kind",it.kind);put("person",it.person);put("phone",it.phone);put("total",it.total);put("paid",it.paid);put("due",it.due);put("note",it.note)
        }) } })
        root.put("commitments", JSONArray().apply { commitments().forEach { put(JSONObject().apply {
            put("title",it.title);put("amount",it.amount);put("account",it.account);put("category",it.category);put("dueDay",it.dueDay);put("note",it.note)
        }) } })
        return root.toString(2)
    }
    fun importJson(json: String) {
        val root = JSONObject(json)
        require(root.optString("format") == "mizaniati-backup-v1") { "ملف النسخة الاحتياطية غير معروف" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("tx",null,null); db.delete("debts",null,null); db.delete("commitments",null,null)
            val a = root.optJSONArray("transactions") ?: JSONArray()
            for(i in 0 until a.length()) { val o=a.getJSONObject(i); addTx(Tx(0,o.getString("kind"),o.getString("title"),o.getDouble("amount"),o.getString("account"),o.optString("category","عام"),o.optString("date",today()),o.optString("note",""))) }
            val b = root.optJSONArray("debts") ?: JSONArray()
            for(i in 0 until b.length()) { val o=b.getJSONObject(i); addDebt(Debt(0,o.getString("kind"),o.getString("person"),o.optString("phone",""),o.getDouble("total"),o.optDouble("paid",0.0),o.optString("due",""),o.optString("note",""))) }
            val d = root.optJSONArray("commitments") ?: JSONArray()
            for(i in 0 until d.length()) { val o=d.getJSONObject(i); addCommitment(Commitment(0,o.getString("title"),o.getDouble("amount"),o.getString("account"),o.optString("category","عام"),o.optString("dueDay",""),o.optString("note",""))) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { FinanceApp(FinanceDb(this)) } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceApp(db: FinanceDb) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    var page by remember { mutableStateOf("الرئيسية") }
    var dialog by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    val txs = remember(refresh) { db.txs() }
    val debts = remember(refresh) { db.debts() }
    val commitments = remember(refresh) { db.commitments() }
    val income = txs.filter { it.kind == "دخل" }.sumOf { it.amount }
    val expenses = txs.filter { it.kind == "مصروف" }.sumOf { it.amount }
    val cash = txs.filter { it.account == CASH }.sumOf { if(it.kind=="دخل") it.amount else if(it.kind=="مصروف") -it.amount else 0.0 }
    val bank = txs.filter { it.account == BANK }.sumOf { if(it.kind=="دخل") it.amount else if(it.kind=="مصروف") -it.amount else 0.0 }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if(uri != null) try { context.contentResolver.openOutputStream(uri)?.use { it.write(db.exportJson().toByteArray()) }; message="تم إنشاء النسخة الاحتياطية بنجاح" } catch(e:Exception) { message="تعذر إنشاء النسخة: ${e.message}" }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri != null) try { val s=context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }; db.importJson(s); refresh++; message="تمت استعادة البيانات" } catch(e:Exception) { message="فشلت الاستعادة: ${e.message}" }
    }
    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if(uri != null) try { context.contentResolver.openOutputStream(uri)?.use { out -> out.write(csv(txs).toByteArray(Charsets.UTF_8)) }; message="تم تصدير ملف CSV المتوافق مع Excel" } catch(e:Exception) { message="تعذر التصدير" }
    }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if(uri != null) try { context.contentResolver.openOutputStream(uri)?.use { out -> out.write(makePdf(txs, income, expenses)) }; message="تم تصدير تقرير PDF" } catch(e:Exception) { message="تعذر تصدير PDF" }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary=androidx.compose.ui.graphics.Color(0xFF173B57),secondary=androidx.compose.ui.graphics.Color(0xFF23877D),background=androidx.compose.ui.graphics.Color(0xFFF4F6F8))) {
        Scaffold(
            topBar={ TopAppBar(title={ Text("My Finance",fontWeight=FontWeight.Bold) }, actions={ Icon(Icons.Default.Menu,null,Modifier.padding(end=16.dp)) }) },
            floatingActionButton={ if(page=="الرئيسية" || page=="العمليات" || page=="الديون" || page=="الالتزامات") FloatingActionButton(onClick={dialog=page}) { Icon(Icons.Default.Add,"إضافة") } },
            bottomBar={ NavigationBar {
                listOf("الرئيسية" to Icons.Default.Home,"العمليات" to Icons.Default.AccountBalanceWallet,"التقارير" to Icons.Default.BarChart,"المزيد" to Icons.Default.Menu).forEach { (label,icon) ->
                    NavigationBarItem(selected=page==label,onClick={page=label},icon={Icon(icon,null)},label={Text(label)})
                }
            } }
        ) { pad ->
            when(page) {
                "الرئيسية" -> Dashboard(Modifier.padding(pad),income,expenses,cash,bank,txs,debts)
                "العمليات" -> TransactionList(Modifier.padding(pad),txs,{ id -> db.deleteTx(id);refresh++ })
                "التقارير" -> Reports(Modifier.padding(pad),txs,income,expenses)
                else -> MorePage(Modifier.padding(pad),debts,commitments,
                    onDebts={page="الديون"},onCommitments={page="الالتزامات"},
                    onBackup={backupLauncher.launch("mizaniati-backup-${today()}.json")},
                    onRestore={restoreLauncher.launch(arrayOf("application/json","text/*"))},
                    onCsv={csvLauncher.launch("mizaniati-report-${today()}.csv")},
                    onPdf={pdfLauncher.launch("mizaniati-report-${today()}.pdf")})
            }
        }
    }
    if(dialog=="الرئيسية" || dialog=="العمليات") AddTransactionDialog({dialog=""}) { db.addTx(it);refresh++;dialog="" }
    if(dialog=="الديون") AddDebtDialog({dialog=""}) { db.addDebt(it);refresh++;dialog="" }
    if(dialog=="الالتزامات") AddCommitmentDialog({dialog=""}) { db.addCommitment(it);refresh++;dialog="" }
    if(page=="الديون") DebtPage(debts, { d, amount -> db.updateDebtPaid(d.id,(d.paid+amount).coerceAtMost(d.total));refresh++ }, { db.deleteDebt(it);refresh++ })
    if(page=="الالتزامات") CommitmentPage(commitments,{ c ->
        db.addTx(Tx(0,"مصروف",c.title,c.amount,c.account,c.category,today(),"سداد التزام دوري"))
        refresh++
    },{db.deleteCommitment(it);refresh++})
    if(message.isNotBlank()) AlertDialog(onDismissRequest={message=""},confirmButton={TextButton(onClick={message=""}){Text("حسناً")}},text={Text(message)})
}

@Composable
fun Dashboard(modifier:Modifier,income:Double,expenses:Double,cash:Double,bank:Double,txs:List<Tx>,debts:List<Debt>) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primary),shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("صافي الدخل بعد المصروفات",color=MaterialTheme.colorScheme.onPrimary.copy(alpha=.8f))
                    Text(fmt(income-expenses),style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                        Column { Text("الدخل",color=MaterialTheme.colorScheme.onPrimary);Text(fmt(income),color=MaterialTheme.colorScheme.onPrimary,fontWeight=FontWeight.Bold) }
                        Column { Text("المصروفات",color=MaterialTheme.colorScheme.onPrimary);Text(fmt(expenses),color=MaterialTheme.colorScheme.onPrimary,fontWeight=FontWeight.Bold) }
                    }
                }
            }
        }
        item { Text("الحسابات",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) { BalanceCard("نقدي",cash,Modifier.weight(1f));BalanceCard("بنكي",bank,Modifier.weight(1f)) } }
        item { Text("ملخص الديون",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold) }
        item { BalanceCard("المتبقي لك",debts.filter{it.kind=="لك"}.sumOf{it.remaining},Modifier.fillMaxWidth()) }
        item { BalanceCard("المتبقي عليك",debts.filter{it.kind=="عليك"}.sumOf{it.remaining},Modifier.fillMaxWidth()) }
        item { Text("آخر العمليات",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold) }
        if(txs.isEmpty()) item { Text("لا توجد عمليات مسجلة حتى الآن.") } else items(txs.take(6)) { TxCard(it) }
    }
}
@Composable fun BalanceCard(title:String,value:Double,modifier:Modifier=Modifier) {
    Card(modifier,shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp)) { Text(title);Text(fmt(value),style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold) } }
}
@Composable fun TxCard(t:Tx) {
    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)) { Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(t.title,fontWeight=FontWeight.SemiBold);Text("${t.date} • ${t.category} • ${t.account}",style=MaterialTheme.typography.bodySmall) }
        Text("${if(t.kind=="دخل") "+" else "-"}${fmt(t.amount)}",fontWeight=FontWeight.Bold,color=if(t.kind=="دخل") MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error)
    } }
}
@Composable fun TransactionList(modifier:Modifier,txs:List<Tx>,delete:(Long)->Unit) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        if(txs.isEmpty()) item { Text("لا توجد عمليات.") }
        items(txs) { t -> Row(verticalAlignment=Alignment.CenterVertically) { Box(Modifier.weight(1f)){TxCard(t)};TextButton(onClick={delete(t.id)}){Text("حذف")} } }
    }
}
@Composable fun Reports(modifier:Modifier,txs:List<Tx>,income:Double,expenses:Double) {
    val byCategory=txs.filter{it.kind=="مصروف"}.groupBy{it.category}.mapValues{e->e.value.sumOf{it.amount}}.toList().sortedByDescending{it.second}
    LazyColumn(modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("التقارير المالية",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold) }
        item { BalanceCard("إجمالي الدخل",income,Modifier.fillMaxWidth()) }
        item { BalanceCard("إجمالي المصروفات",expenses,Modifier.fillMaxWidth()) }
        item { BalanceCard("الفائض / العجز",income-expenses,Modifier.fillMaxWidth()) }
        item { Text("المصروفات حسب التصنيف",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold) }
        if(byCategory.isEmpty()) item { Text("لا توجد مصروفات مصنفة.") }
        items(byCategory) { (cat,total) -> Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(cat);Text(fmt(total),fontWeight=FontWeight.Bold)} }
        item { Text("يمكن تصدير التفاصيل إلى CSV لفتحها في Excel أو إلى PDF من قسم المزيد.") }
    }
}
@Composable fun MorePage(modifier:Modifier,debts:List<Debt>,commitments:List<Commitment>,onDebts:()->Unit,onCommitments:()->Unit,onBackup:()->Unit,onRestore:()->Unit,onCsv:()->Unit,onPdf:()->Unit) {
    Column(modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("إدارة التطبيق",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        Text("الحسابات المعتمدة: نقدي وبنكي فقط.")
        Button(onClick=onDebts,Modifier.fillMaxWidth()){Text("إدارة الديون (${debts.size})")}
        Button(onClick=onCommitments,Modifier.fillMaxWidth()){Text("الالتزامات الشهرية (${commitments.size})")}
        Divider()
        Text("التقارير والنسخ الاحتياطي",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
        OutlinedButton(onClick=onCsv,Modifier.fillMaxWidth()){Text("تصدير تقرير Excel (CSV)")}
        OutlinedButton(onClick=onPdf,Modifier.fillMaxWidth()){Text("تصدير تقرير PDF")}
        OutlinedButton(onClick=onBackup,Modifier.fillMaxWidth()){Text("إنشاء نسخة احتياطية")}
        OutlinedButton(onClick=onRestore,Modifier.fillMaxWidth()){Text("استعادة نسخة احتياطية")}
        Text("البيانات محفوظة محلياً على الجهاز ولا يحتاج التطبيق إلى الإنترنت.")
    }
}
@Composable fun DebtPage(debts:List<Debt>,pay:(Debt,Double)->Unit,delete:(Long)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("الديون المستحقة لك وعليك",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold) }
        if(debts.isEmpty()) item { Text("لا توجد ديون مسجلة.") }
        items(debts) { d ->
            var payText by remember(d.id) { mutableStateOf("") }
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                Text("${d.person} — ${if(d.kind=="لك") "دين لك" else "دين عليك"}",fontWeight=FontWeight.Bold)
                Text("الأصل: ${fmt(d.total)} | المسدد: ${fmt(d.paid)} | المتبقي: ${fmt(d.remaining)}")
                Text("الاستحقاق: ${d.due.ifBlank{"غير محدد"}}")
                Row(verticalAlignment=Alignment.CenterVertically) {
                    OutlinedTextField(payText,{payText=it},Modifier.weight(1f),label={Text("مبلغ السداد")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
                    TextButton(onClick={payText.toDoubleOrNull()?.takeIf{it>0 && it<=d.remaining}?.let{pay(d,it);payText=""}}){Text("تسجيل سداد")}
                    TextButton(onClick={delete(d.id)}){Text("حذف")}
                }
            } }
        }
    }
}
@Composable fun CommitmentPage(items:List<Commitment>,pay:(Commitment)->Unit,delete:(Long)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("الالتزامات الدورية",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold) }
        if(items.isEmpty()) item { Text("لا توجد التزامات مسجلة.") }
        items(items) { c -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
            Text(c.title,fontWeight=FontWeight.Bold);Text("${fmt(c.amount)} • ${c.account} • يوم الاستحقاق: ${c.dueDay}")
            Row { TextButton(onClick={pay(c)}){Text("تسجيل دفع هذا الشهر")};TextButton(onClick={delete(c.id)}){Text("حذف")} }
        } } }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddTransactionDialog(close:()->Unit,save:(Tx)->Unit) {
    var title by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var kind by remember{mutableStateOf("دخل")}
    var account by remember{mutableStateOf(CASH)};var category by remember{mutableStateOf("عام")};var date by remember{mutableStateOf(today())};var note by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=close,title={Text("إضافة عملية مالية")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
        OutlinedTextField(title,{title=it},label={Text("الوصف")},singleLine=true)
        OutlinedTextField(amount,{amount=it},label={Text("المبلغ")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
        Row { listOf("دخل","مصروف").forEach { FilterChip(kind==it,{kind=it},label={Text(it)});Spacer(Modifier.width(6.dp)) } }
        Text("الحساب")
        Row { listOf(CASH,BANK).forEach { FilterChip(account==it,{account=it},label={Text(it)});Spacer(Modifier.width(6.dp)) } }
        OutlinedTextField(category,{category=it},label={Text("التصنيف")},singleLine=true)
        OutlinedTextField(date,{date=it},label={Text("التاريخ (YYYY-MM-DD)")},singleLine=true)
        OutlinedTextField(note,{note=it},label={Text("ملاحظات")},singleLine=true)
    }},confirmButton={TextButton(onClick={amount.toDoubleOrNull()?.takeIf{it>0}?.let{save(Tx(0,kind,title,it,account,category.ifBlank{"عام"},date,note))}}){Text("حفظ")}},dismissButton={TextButton(onClick=close){Text("إلغاء")}})
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddDebtDialog(close:()->Unit,save:(Debt)->Unit) {
    var person by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var total by remember{mutableStateOf("")};var kind by remember{mutableStateOf("لك")};var due by remember{mutableStateOf("")};var note by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=close,title={Text("إضافة دين")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
        Row { FilterChip(kind=="لك",{kind="لك"},label={Text("دين لي")});Spacer(Modifier.width(8.dp));FilterChip(kind=="عليك",{kind="عليك"},label={Text("دين عليّ")}) }
        OutlinedTextField(person,{person=it},label={Text("اسم الشخص")})
        OutlinedTextField(phone,{phone=it},label={Text("رقم الهاتف (اختياري)")})
        OutlinedTextField(total,{total=it},label={Text("المبلغ")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        OutlinedTextField(due,{due=it},label={Text("تاريخ الاستحقاق")})
        OutlinedTextField(note,{note=it},label={Text("ملاحظات")})
    }},confirmButton={TextButton(onClick={total.toDoubleOrNull()?.takeIf{it>0}?.let{save(Debt(0,kind,person,phone,it,0.0,due,note))}}){Text("حفظ")}},dismissButton={TextButton(onClick=close){Text("إلغاء")}})
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddCommitmentDialog(close:()->Unit,save:(Commitment)->Unit) {
    var title by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var account by remember{mutableStateOf(CASH)};var category by remember{mutableStateOf("التزامات")};var day by remember{mutableStateOf("1")};var note by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=close,title={Text("إضافة التزام شهري")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
        OutlinedTextField(title,{title=it},label={Text("اسم الالتزام")})
        OutlinedTextField(amount,{amount=it},label={Text("المبلغ")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        Row { listOf(CASH,BANK).forEach { FilterChip(account==it,{account=it},label={Text(it)});Spacer(Modifier.width(6.dp)) } }
        OutlinedTextField(category,{category=it},label={Text("التصنيف")})
        OutlinedTextField(day,{day=it},label={Text("يوم الاستحقاق من 1 إلى 31")})
        OutlinedTextField(note,{note=it},label={Text("ملاحظات")})
    }},confirmButton={TextButton(onClick={amount.toDoubleOrNull()?.takeIf{it>0}?.let{save(Commitment(0,title,it,account,category,day,note))}}){Text("حفظ")}},dismissButton={TextButton(onClick=close){Text("إلغاء")}})
}

fun csv(txs:List<Tx>):String {
    val sb=StringBuilder("\uFEFFالنوع,الوصف,المبلغ,الحساب,التصنيف,التاريخ,ملاحظات\n")
    txs.forEach { t -> sb.append(listOf(t.kind,t.title,t.amount.toString(),t.account,t.category,t.date,t.note).joinToString(",") { "\""+it.replace("\"","\"\"")+"\"" }).append("\n") }
    return sb.toString()
}
fun makePdf(txs:List<Tx>,income:Double,expenses:Double):ByteArray {
    val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create())
    val paint=Paint().apply{textSize=16f;isAntiAlias=true}
    var y=50f
    page.canvas.drawText("Mizaniati - Financial Report",40f,y,paint);y+=35
    paint.textSize=12f
    page.canvas.drawText("Income: ${fmt(income)}",40f,y,paint);y+=22
    page.canvas.drawText("Expenses: ${fmt(expenses)}",40f,y,paint);y+=22
    page.canvas.drawText("Net: ${fmt(income-expenses)}",40f,y,paint);y+=35
    page.canvas.drawText("Date       Type       Description       Amount       Account",40f,y,paint);y+=22
    txs.take(27).forEach { t ->
        val line="${t.date}   ${t.kind}   ${t.title.take(22)}   ${fmt(t.amount)}   ${t.account}"
        page.canvas.drawText(line,40f,y,paint);y+=20
    }
    doc.finishPage(page);val out=java.io.ByteArrayOutputStream();doc.writeTo(out);doc.close();return out.toByteArray()
}
