# My Finance – Personal Finance Manager (Version 2.0)

Android personal finance manager. The app display name is My Finance; the interface content remains Arabic.

## الحسابات
- نقدي
- بنكي

لا توجد حسابات أو محافظ أخرى.

## الوظائف الموجودة
- تسجيل الدخل والمصروفات مع المصدر/التصنيف والحساب والتاريخ والملاحظات.
- سجل العمليات وإمكانية حذف العملية.
- ملخص إجمالي الدخل والمصروفات والفائض/العجز.
- أرصدة الحساب النقدي والبنكي.
- إدارة الديون التي لك وعليك، وتسجيل السداد الجزئي والمتبقي.
- الالتزامات الدورية، وتسجيل دفع الالتزام كعملية مصروف.
- تقرير إجمالي وتوزيع المصروفات حسب التصنيف.
- تصدير تفاصيل العمليات إلى CSV متوافق مع Excel.
- تصدير تقرير PDF.
- إنشاء نسخة احتياطية JSON واستعادتها عبر منتقي الملفات.
- قاعدة بيانات SQLite محلية، ولا توجد أذونات إنترنت في التطبيق.

## البناء
1. فك ضغط الملف.
2. افتح المجلد في Android Studio.
3. نفذ Gradle Sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

## GitHub Actions
ارفع محتويات المجلد إلى مستودع GitHub. سير العمل `.github/workflows/android.yml` يبني APK عند الدفع أو التشغيل اليدوي.

## تنبيهات وحدود هذه النسخة
- التطبيق نموذج عملي أولي قابل للاختبار، وليس نظاماً محاسبياً مدققاً.
- النسخ الاحتياطي والاستعادة يستبدلان البيانات الحالية بمحتوى النسخة المختارة؛ احتفظ بنسخة حديثة قبل الاستعادة.
- PDF في هذه النسخة تقرير مبسط باللغة الإنجليزية لتفادي مشاكل تشكيل الخط العربي في مولد PDF الحالي؛ واجهة التطبيق نفسها عربية.
- CSV يفتح في Excel ويمكن استيراده كجدول بيانات.
- لا توجد مزامنة سحابية أو رسائل SMS أو تتبع تلقائي لحركة الحسابات.
- سداد الالتزام يسجل مصروفاً جديداً كل مرة تضغط فيها الزر؛ تجنب الضغط المكرر.
- لا تسجل أرقاماً أو بيانات حساسة لا تحتاج إليها، واحفظ النسخة الاحتياطية في مكان آمن.


## Monthly financial separation
The dashboard, transactions list, and reports include a month selector with Arabic month names.
Income, expenses, cash/bank net movement, category summaries, CSV exports, and PDF reports are
calculated only from transactions whose date belongs to the selected month. New transactions
default to the selected month, and the date must match that month before saving. Existing
transactions remain in the database and are assigned to months using their saved date.
